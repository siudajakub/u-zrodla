# Kolejna fala InvestWatch po panelu SOL i TERRA

Analityk chce wiedzieć, którą publikację otworzyć, co dokładnie zauważył system i czy firma potwierdza współpracę. Pulpit zapisuje cytat lub pomiar, adres, wersję i decyzję. Wynik liczbowy ustawia kolejność przeglądu. Kwalifikacja prawna wymaga oceny człowieka.

M1, M2 i M3 to trzy moduły konkursowe. Wszystkie mają implementację, różnią się głębokością i jakością dowodów. Oficjalne wymagania i próby pozostają w [arkuszu odbioru](ODBIOR-UKNF.md), docelowy zakres w [planie realizacji](PLAN-REALIZACJI.md), wcześniejsze wykonane próby w [raporcie demo](DEMO-ODBIOR.md).

| Obszar | Co działa i dlaczego są ograniczenia | Następny odbiór |
|---|---|---|
| M1, osoby trzecie | Wyszukiwanie tematyczne Apple Podcasts i PeerTube, RSS, powiązane profile, cztery obserwowane konta YT/TikTok. Publiczne opisy pomijają mowę, dlatego są lokalne ASR, odsłuch i czas. Najlepsze przypadki promocji wyłącznie głosowej są syntetyczne. | Prześledzić rzeczywistą publikację od odkrycia poprzez dowód do sprawy; sprawdzić powtórny skan, brak fałszywego połączenia marek, pytanie do firmy i porównanie aneksu. Pokazać zakres modalności i źródło każdej deklaracji. |
| M2, marketing własny firmy | Lista 19 kontroli i zapisane zrzuty/DOM. W badanym stanie 54 z 57 pól miały brak danych. Zbieranie tekstu na żywo nie daje geometrii widoku. | Najwyższy priorytet. Na publicznej reklamie własnej firmy połączyć korzyść z właściwym ostrzeżeniem, zapisać aktualny DOM i zrzut desktop/mobile, porównać położenie, wielkość i kontrast. Kliknięcie kryterium ma otworzyć dowód dokładnie tej wersji. |
| M3, oferta doradztwa | Wykrywa treść oferty do sprawdzenia i podobne nazwy z rejestru. Sam brak nazwy albo podobna nazwa nie rozstrzygają uprawnień. | Jedna rzeczywista oferta PL z cytatem o personalizacji, instrumencie i czynności. Ustalić tożsamość i datowany zakres zezwolenia we właściwym rejestrze, odróżnić niepewność od naruszenia. Dodać kontrolę edukacyjną. |
| Walidacja i pokaz | Suwak przelicza FP/FN dla 4 publicznych i 9 syntetycznych przykładów. E5 ocenia podobieństwo tekstu, reguły priorytet, Vosk transkrybuje. | Odłożyć niezależne rzeczywiste kampanie, oznaczyć przed obejrzeniem wyników, grupować powtórzenia; zapisać błędy i mianowniki. Uzupełnić PDF o architekturę i wykrytą dzięki recenzji awarię Huey. |

## Interfejs po sprawdzeniu funkcji

J chce prostego, jasnego stanowiska opartego na gotowych komponentach Astryx. Obecny podgląd Neutral zmienia głównie wygląd tego samego pulpitu. Wybrać jeden istniejący szablon stanowiska/listy ze szczegółami z katalogu Astryx, sprawdzić jego nazwę i API dostępnych komponentów. Wykorzystać jego układ, nawigację, tabelę lub listę, filtry, zakładki, pola i przyciski. Pierwszy ekran ma umożliwić wybór sprawy, odtworzenie dowodu i zapis decyzji. Stan źródeł i kalibrację udostępnić jako widoki dodatkowe. Usunąć powtórzenia tekstu i ozdobne elementy. Zachować formularze, fokus, pozycję odtwarzacza, dostępność, obsługę błędów i odczyt offline. Przed zastąpieniem pulpitu pokazać J działający widok na danych i porównać te same zadania z wersją bazową.

## Kolejność pracy

1. Wyjaśnić J w kilku zdaniach produkt i ograniczenia. Odtworzyć obecną ścieżkę w Chromium i ustalić braki względem każdego wiersza arkusza UKNF.
2. Przydzielić właścicieli otwartych prób. Zacząć od M2, równolegle zbadać M3 i zbiór walidacyjny. Uwagi do M1, UI, integracji i dokumentacji prowadzić aż do odbioru pełnego zakresu. Przy przeszkodzie zewnętrznej udokumentować źródło i dostępny wariant.
3. Po integracji powtarzać testy regresji, czyste starty offline i dwuminutowy pokaz. SOL i TERRA oceniają działający wynik niezależnie według wag UKNF. Ostatni panel przyznał po 77/100, a 91,3 dotyczyło wcześniejszego planu.
